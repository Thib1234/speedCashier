<?php $__env->startSection('content'); ?>
<show 
    :data="<?php echo e(json_encode($sales)); ?>" 
    :total_sales="<?php echo e($total_sales); ?>" 
    :start-date="'<?php echo e($startDate); ?>'" 
    :end-date="'<?php echo e($endDate); ?>'" 
    :total-sales-htva="<?php echo e($totalSalesHtva); ?>"
    :total-htva="<?php echo e($totalHtva); ?>"
></show>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\t.vandenbemden\Documents\GitHub\speedCashier\resources\views/compta/show.blade.php ENDPATH**/ ?>