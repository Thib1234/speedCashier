<?php $__env->startSection('content'); ?>

<?php if(auth()->guard()->check()): ?>
<cashier-test></cashier-test>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\t.vandenbemden\Documents\GitHub\speedCashier\resources\views/cashier_test.blade.php ENDPATH**/ ?>