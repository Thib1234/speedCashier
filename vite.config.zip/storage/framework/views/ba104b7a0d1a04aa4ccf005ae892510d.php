<?php $__env->startSection('content'); ?>
	<products-list></products-list>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\t.vandenbemden\Documents\GitHub\speedCashier\resources\views/products/index.blade.php ENDPATH**/ ?>