@extends('app')

@section('content')
	<create-client></create-client>
@endsection