@extends('app')

@section('content')
<create-account></create-account>
@endsection