@extends('app')

@section('content')
	<create-product></create-product>
@endsection