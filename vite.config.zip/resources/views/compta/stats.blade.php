@extends('app')

@section('content')
<stats></stats>
@endsection