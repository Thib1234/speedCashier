@extends('app')

@section('content')
<stats-toilettage></stats-toilettage>
@endsection