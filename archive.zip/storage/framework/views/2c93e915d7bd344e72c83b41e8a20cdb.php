<?php $__env->startSection('content'); ?>
<daily></daily>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tvdbd\Documents\speedCashier\resources\views/compta/daily.blade.php ENDPATH**/ ?>