<?php $__env->startSection('content'); ?>
<acounts-list></acounts-list>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tvdbd\Documents\speedCashier\resources\views/acompte/show.blade.php ENDPATH**/ ?>