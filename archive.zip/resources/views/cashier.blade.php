@extends('app')

@section('content')

@auth
<cashier></cashier>
@endauth
	
@endsection