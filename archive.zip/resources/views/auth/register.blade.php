@extends('app')

@section('content')

	<create-user></create-user>

@endsection