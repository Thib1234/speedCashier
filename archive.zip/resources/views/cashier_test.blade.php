@extends('app')

@section('content')

@auth
<cashier-test></cashier-test>
@endauth

@endsection
