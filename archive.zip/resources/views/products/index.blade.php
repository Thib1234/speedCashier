@extends('app')

@section('content')
	<products-list></products-list>
@endsection