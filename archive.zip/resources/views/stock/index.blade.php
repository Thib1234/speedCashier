@extends('app')

@section('content')
	<stock-list></stock-list>
@endsection