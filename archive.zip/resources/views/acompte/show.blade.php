@extends('app')

@section('content')
<acounts-list></acounts-list>
@endsection