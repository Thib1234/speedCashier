@extends('app')

@section('content')
	<clients-list></clients-list>
@endsection