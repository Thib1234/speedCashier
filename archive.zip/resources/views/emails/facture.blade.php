<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Facture</title>
</head>
<body>
	<h1>Facture</h1>
	<p>
		Bonjour,
		<br>
		Vous trouverez ci-joint votre facture.
	</p>
    <p>Caroline pour Cesar et Rosalie</p>
</body>
</html>
