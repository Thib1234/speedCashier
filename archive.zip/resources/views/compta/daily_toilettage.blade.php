@extends('app')

@section('content')
<daily-toilettage></daily-toilettage>
@endsection