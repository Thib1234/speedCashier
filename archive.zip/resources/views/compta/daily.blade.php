@extends('app')

@section('content')
<daily></daily>
@endsection