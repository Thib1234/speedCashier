@extends('app')

@section('content')
<list-invoices></list-invoices>
@endsection
